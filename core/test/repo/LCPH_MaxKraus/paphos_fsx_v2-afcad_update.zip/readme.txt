Paphos International Airport for FSX 2.00 - Updated AFCAD
---------------------------------------------------

General update for afcad/ade file from user feedback since release.

Changed.

- Adjusted parking numbering
- Adjusted taxi widths and gate widths
- Adjuasted ground markings to reflect up to date layout

Installation

1. Backup the existing files 14_LCPH_lines.bgl and LCPH_ADEX_XX.BGL.
2. Copy the files in the zip to your Addon Scenery\PAPHOS_FSX_v2\Scenery folder. Overwrite when prompted.


Max Kraus
17 April 2011

maxkraus08@googlemail.com
