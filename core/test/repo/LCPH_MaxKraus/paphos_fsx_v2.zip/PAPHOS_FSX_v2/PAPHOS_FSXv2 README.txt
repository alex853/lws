PAPHOS INTERNATIONAL AIRPORT - VERSION 2.00

For Microsoft Flight Simulator X
-------------------------------------------

This is a complete new standalone revised scenery that superscedes the Version 1, filename paphos_fsx_v1.zip. You should remove V1 prior to installing Version 2.

Version 2.00
------------ 

*** Main Fix
- Runway lighting system completely rebuilt to run with better FPS
- Texture improvements

Added
- Vehicle path network. If you move your airport vehicle slider up now you will get moving trucks on the apron in correct places.

========================
30/10/10


Original Readme.

This scenery took me a total of 8 months to create from scratch. Everything you see was hand made in Gmax and Photoshop using the SDK and non-SDK design techniques that are commonly deployed by today's commercial scenery design houses.


Background

Paphos International Airport (IATA: PFO, ICAO: LCPH) is located 6 km southeast from the city of Paphos, Cyprus. It is the country's second largest airport after Larnaca International Airport. Paphos airport is a hub for tourists on holiday in beautiful western Cyprus, providing access to popular resorts and beaches in the area. It receives flights from all over mainland Europe and the UK and can serve aircraft up to mainly B767/A330 in size but mostly smaller jets in the 737/A320 range.

The airport has one, ILS equipped east-west runway and a drive through style apron for remote aircraft parking served by buses. An air force base (Panandreou AFB) is located on the northeast side of the field with hardened aircraft shelters, hangars and barracks. Large aricraft such as C17, C30 and Antonov transports can often be seen here. It is believed attack helicopters and training aircraft are housed here in the hardened shelters.

In May 2006, Hermes Airports Limited took over the construction, development and operation of Larnaca and Paphos airports. A new terminal for Paphos opened in November 2008, providing the airport with increased passenger capacity and modernised facilities. The old terminal is now being used for cargo and freight handling.

Paphos is also the resting place of two Royal Air Force WW2 Avro Shackleton Aircraft, mainly serving in reconnaissance roles. WL747 and WL757 are AEW2 aircraft. Several attempts to get them flying again have failed and it looks like Paphos will be the final resting place of these former beauties. The two Shackletons can now be found at the north western end of the field. 

Scenery Features

This new scenery for Paphos features the following;
- Custom made Gmax photorealistic ground polygons for the airport and surrounding area.
- Apron parking areas for commercial, military, and GA zones.
- Gmax modelled 3D buildings for old and new terminals, maintenance hangars, GA flying club, ATC tower complex, military base, and other objects around the field.
- Gmax animated traffic and other ground objects.
- Custom designed night lighting
- The two RAF Avro Shackletons beside runway 11 are immortalised in the scenery also.


Installation instructions

Please read carefully, as not all scenery is the same! You could end up creating problems, which of course I won't be responsible for in any way. No existing FSX files are overwritten during this process. The scenery will not result in missing files or textures. If this is experienced, check you have not made any other 3rd party changes to your installation and if so, seek advice from the appropriate channels. ** Please ensure you have FSX installed with SP2A or Acceleration packs added. It is not known if this scenery is compatible with SP1 installations** 

I have not tested this scenery for compatibility with DX10 Preview mode.

1. Make a new empty folder in the location of your choice.
2. Unzip the downloaded file into the newly made folder, preserving the zip file folder structure. You should now have a folder called Paphos FSX and inside Scenery, Texture. A folder called Effects is also created. 
3. Copy the files inside the Effects folder to your  "Flight Simulator X/Effects" folder.
4. Copy the "Paphos FSXv2" folder to your "Flight Simulator X/Addon Scenery" folder.
5. Start Microsoft Flight Simulator X and call up your scenery library.
6. Click "ADD AREA" and browse to your new PAPHOS FSXv2 folder and add this folder.
7. Click OK and FSX will now rebuild the scenery library.
8. Restart FSX and you are done!


Remarks

- Should you experience aircraft "Crashes" (the aircraft type) using this scenery, it is recommended that you turn off Crashes and Damage detection in FSX reality settings. This will ensure you do not collide with invisible scenery objects. 

- Frame rates for me (on Overclocked Core i7-920, @3.8GHz, 6Gb DDR3, GTX285) are in the range of 50-80 fps. Older machines will of course experience lower frame rates. Use your sliders to set up FSX suitably.

I have divided the more common smaller scenery objects into several small placement libraries. Should you experience low frame rates with low-end hardware then you can simply disable certain bgl's by renaming the extension "bgl" to something else. Suitable files would be lcph_forest.bgl (the trees around the car park) and and lcph_carpark.bgl (the actual cars in the car park) which may get you some fps back. 


Tools used: 

Gmax (for 3D Modelling)
Photoshop CS8.0, DXTBmp (for Texture artwork)
Flight1 Instant Scenery (for library Object placement)
SBuilderX (for coastline alterations, flatten, landclass)
Airport Design Editor 9X (for Afcad work, fences, approach data, exclude)


Thanks to all the great forums and people who offer advice and knowledge in the community.

Regards,

Max Kraus
maxkraus08@googlemail.com
October 20 2010

Original upload is to Avsim library. To upload to other sites please seek permission from the author. I probably won�t say no, but just please ask. Thanks
