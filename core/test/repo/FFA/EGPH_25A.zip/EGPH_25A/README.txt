Installation
------------

Unzip the ZIP file, and place the directory containging

- Scenery directory
- Texture directory
- Images
- README.txt

to the folder "Addon Scenery" or another folder of your choice, and activate 
this directory in FSX. To do this

- open the scenery library,
- add area,
- navigate into the directory,
- press OK,
- click into an empty area in the files display.
- press OK to exit the library editor.

The scenery has been tested with FSX Steam Edition and Orbx Vector and OpenLC Europe. 
It should work in the default simulation, however.

Description
-----------

Frame rate friendly version of EGPH, Edinburgh Airport. All gates and taxiways are
exact as to Google Earth. Jetways are working, as well as approach lights in low
visibility.

In case of problems contact "mga010@gmx.de".

See other sceneries at 

https://sites.google.com/site/fsxvideosairports/

Have fun!
