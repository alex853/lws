Larnaka LCLK, Cyprus, for FSX
by Sidney Schwartz

Completely re-done. Adds new terminal and taxiways. Custom buildings. Realish.

The only additional files required is my Lights SS V2+ object library, but only if you don't already have it installed. If you don't already have it, you can download it here:

http://library.avsim.net/esearch.php?CatID=fs2004sd&DLID=142190

Installation: Unzip Larnaka LCLK.zip. Move the entire folder Larnaka LCLK into your FSX/ADDON SCENERY folder and add it to your FSX Scenery Library list.

Thanks to: Jon "Scruffyduck" Masterson for his wonderful Airport Design Editor X and other tools, Arno Gerritson for his wonderful Model Converter X and other tools, and the folks at Trimble for the free version of Sketchup.

Terms of Usage
==============
This scenery is freeware. Under no circumstances may it be sold or incorporated, wholly or in part, into any payware product. This scenery may be made available for downloading from other web sites provided it is not modified in any way and uploaded complete and in its original form. Custom scenery objects made for this scenery may NOT be used in other scenery, freeware or payware.

Sidney Schwartz sidney.schwartz@comcast.net
11/11/2016