


Heathrow Intl Airport - EGLL - UK by Ray Smith


This update was designed with the latest version of ADE (Airport Design Editor) and made only for the FSX default airport: Terminal 2 demolished, pier 6 added, taxiways and taxi signs updated, assigned parking with extra parking with gates for the A380, extra fuel trucks, start location added to the helipad, support vehicle roads rebuilt and many other improvements, airport views are from inside the control tower (when in tower view) please view the readme before installation




Please Note: 
The Default Terminals 1 and 2 in FSX are combined and created as one Library Object, so deleting this library object (to remove T2) removes both terminals, 
I have rebuilt Terminal 1 with other airport buildings, the installation describes how to add the textures for these buildings so they show up at the airport, so please do not expect to see the original Terminal 1 buildings.



To Install:

1. Take the EGLL_ADE_RS.BGL file and place it into: Flight Simulator X/Addon Scenery/scenery folder (overwrite/delete my old file if you are using it)

2. To add the textures for Terminal 1 follow these steps:

"Browse" to the Flight Simulator X\Scenery\NAME\texture folder, Scroll down the list until you see these 6 Textures:

MIA_Concourses_C_D_Satalites.dds
MIA_Concourses_C_D_Satalites_LM.dds
MIA_Concourses_C_D_SatalitesSpecular.dds
MIA_Concourses_G_H.dds
MIA_Concourses_G_H_LM.dds
MIA_Concourses_G_HSpecular.dds

"COPY" these textures from that folder and "PASTE" them into the Flight Simulator X/Addon Scenery/texture folder, another option is the FSX/Scenery/Global/Texture folder. 
Please make sure you have "COPIED" the right textures into the correct folder, 

3. Start up the Flight Sim and the changes will be present.


IMPORTANT NOTE: PLEASE ONLY USE THIS EGLL.BGL FILE:
  i.e: make sure there is only my EGLL_ADE_RS.BGL file in the Addon Scenery/scenery folder at any time, remove/delete any other EGLL.bgl to avoid incorrect parking and other airport conflicts.

If you have my previous version of EGLL also Delete the "EGLL_ADE_OBJ.BGL" from the "FSX/Scenery/Global/scenery" folder as it is not needed with this version.

If you have any AI Traffic Addons please make sure they have "NOT" installed another Afcad for this airport as this will also cause a conflict.



OPTIONAL: 
There are flood lights in the cargo area, if you wish to see these you need to add the textures for them (this is not mandatory as they are only scenery objects set at "Dense") please follow these steps:

"Browse" to the FSX\Scenery\ASIA\Texture folder. Scroll down the list until you see NAR_jetway.dds (day texture) and NAR_jetway_LM.dds (night texture).

"COPY" them from that folder and "PASTE" them into the Scenery/Global/Texture folder. 



To Uninstall:

1. Delete/remove the EGLL_ADE_RS.BGL file and the texture files and the default airport will then be active.




              [COPYRIGHT]

NO PART OF THESE FILES CAN BE SOLD OR DISTRIBUTED FOR FINANCIAL GAIN, THIS IS SOLELY FREEWARE
THESE FILES ARE NOT TO BE BUNDLED OR RE-UPLOADED WITHOUT THE AUTHORS CONSENT.
THESE FILES ARE NOT TO BE CHANGED AND RE-UPLOADED WITHOUT THE AUTHORS CONSENT.



         Acknowledgements
  _________________________________


ADE Utility (Freeware) - Jon Masterson.........http://www.scruffyduck.org.uk
This also has a download center for many other ADE files.

Please visit here for more information...........http://www.airportdesigneditor.co.uk

Any questions relating to ADE can be answered at www.fsdeveloper.com/forum......look for Airport Design Editor

And my ever enduring wife to put up with the hours spent making these files.



TIP: when at EGLL in tower view: go to your control settings and look for the "View track/pan Toggle"
allocate a keyboard key stroke to it (i allocated a button on my controller) this will unlock the user aircraft, then you can use the hat switch to pan 360 degrees around the airport, hitting the key stroke again (in my case a button) will return you to the user aircraft position

            Enjoy and Happy flying

                          Ray      

                    cry@orcon.net.nz 


