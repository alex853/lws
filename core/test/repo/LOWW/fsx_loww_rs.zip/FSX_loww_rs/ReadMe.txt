








LOWW - Schwechat Airport, Vienna, Austria by Ray Smith



This is a very accurate version for Schwechat Intl Airport to reflect todays situation with two optional files: one version with the Crosswind runway operating where both runways will be used for takeoff/landing and one version as the default airport runway operation: assigned parking at all terminals now as per their website, extra parking including a gate for the A380, start location added to the helipad, all ILS approaches, taxiways and taxi signs updated and corrected to the latest charts, extra fuel trucks, support vehicle roads rebuilt and many other scenery improvements and objects added, airport views are from inside the control tower (when in tower view) please view the readme before installation.





There are 3 BGL files: LOWW_RS.BGL, LOWW_CW_RS.BGL and a LOWW_CVX.bgl




Runway Operation Files:

The LOWW_CW_RS.BGL file is with the Xwind runway activated where both runways will be used simultaneously,    
The LOWW_RS.BGL file is the same as the default airport runway operation. 
Assigned parking is the same in both files.



To Install:

If you are using my earlier version please remove/delete these files first including the "LOWW_ADE_OBJ.BGL" that was placed in the "FSX/Scenery/Global/scenery" folder, if you would rather keep them remove them to another folder not associated with FSX.


1. Take the runway operation file of your choice (only one) and the LOWW_CVX.BGL file and place both of these files into: 

           Flight Simulator X/Addon Scenery/scenery folder

2. Start up the Flight Sim and the changes will be present


IMPORTANT: Make sure you do not have any other "LOWW airport file/s" in use to avoid any airport conflicts




IMPORTANT NOTE: PLEASE ONLY USE ONE RUNWAY OPERATION FILE AT ANY TIME:
  i.e: make sure there is only ONE of the LOWW_RS.BGL FILES are in the Addon Scenery\scenery folder at any time, remove/delete any other LOWW.bgl to avoid incorrect parking and other airport conflicts.

If you have any "PAYWARE" AI Traffic Addons please make sure they have "NOT" installed an Afcad for this airport as this will also cause a conflict.



PLEASE NOTE: when using ATIS with the LOWW_CW_RS.BGL file you will hear the fake runways as well as the airport runways, this is the method used in activating non parallel runways and should be ignored or if preferred use the version LOWW_RS.BGL.



To Uninstall:

1. Delete/remove the BGL files and the default airport will then be active.




NOTE: only those with Acceleration installed will see the vehicles in the car parks and the flood lights in the cargo area.





              [COPYRIGHT]      [PLEASE READ TWICE] 

NO PART OF THESE FILES CAN BE SOLD OR DISTRIBUTED FOR FINANCIAL GAIN, THIS IS SOLELY FREEWARE
THESE FILES ARE NOT TO BE BUNDLED OR RE-UPLOADED WITHOUT THE AUTHORS PERMISSION
NO PART OF THESE FILES CAN BE RE-UPLOADED WITHOUT THE AUTHORS PERMISSION
THESE FILES ARE NOT TO BE CHANGED/MODIFIED AND RE-UPLOADED WITHOUT THE AUTHORS PERMISSION.





                     Acknowledgements
                _________________________________

ADE Utility (Freeware) - Jon Masterson.........http://www.scruffyduck.org.uk/
This also has a download centre for many other ADE files.

Please visit here for more information...........http://www.airportdesigneditor.co.uk

Any questions relating to ADE can be answered at www.fsdeveloper.com/forum......look for Airport Design Editor

Jim Vile for his Technique that activates crosswind runways, also for the invaluable help over the years, RIP my friend.

Victor Nauta for the permission to use his scenery objects.

Alexander Gonzalez for airport information to make this airport as accurate as possible.




TIP: when in tower view at LOWW: 
Go to your control settings and look for the "View track/pan Toggle"
Allocate a keyboard key stroke to it (i allocated a button on my controller) this will unlock the user aircraft, then you can use the hat switch to pan 360 degrees around the airport, hitting the key stroke again (in my case a button) will return you to the user aircraft position

       Enjoy and Happy flying
 
                      Ray  

                   cry@orcon.net.nz






