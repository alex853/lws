PATCH EDDL v1.0 by Max Epperlin for EDDL by Thomas Ruth (07/2011)
--------------------------------------------------------

Aenderungen
----------
Mit diesem Patch werden folgende Dinge an der Duesseldorf Szenerie von Thomas Ruth verbessert/ver�ndert:
- alle dekorativen Fahrzeugwege angepasst
- Zaeune verschoben/korrigiert
- Stra�en verschoben/korrigiert
- 05L/23R heading korrigiert
- Rollwege an anhand von Luftbild u. Chart angepasst
- Bauarbeiten ber�cksichtigt (zb. Rollweg M verschoben und N,L hinzugef�gt, etc), anhand von GND-Charts
- alle Parkpositionen hinzugef�gt, bis auf Doppelbelegung und GA (93 St�ck nun insgesamt)
- Parkpositionen anhand der GND-Chart ausgerichtet
- Apron Markierungen mit ADE Mitteln versucht nachzuahmen.
- alle Geb�ude neu positioniert damit sie zu Luftbildern passen (dabei habe ich die Lichtmasten, Schutzz�une, westlichen B�rogeb�ude und H�ngebahn in GMAX angepasst)
- Airlines den Parkpositionen zugewiesen 
- T-Offsets an den Parkpositionen ver�ndert, hinzugef�gt
- Apronlayout korrigiert


Installation:
-------------
Einfach die alte EDDL Szenerie deaktivieren und l�schen, das gilt f�r jede Art von Szenerie die den D�sseldorfer Flughafen darstellt.
Danach einfach diese neue Version in "Addon Scenery" im Hauptordner vom FSX kopieren. Dann diese im FSX aktivieren.
PS: Um Fehler zu verhinder, die Szenerie sollte mit "h�hster" Priorit�t (1) in die SzenerieBib. eingef�gt werden. (ganz oben)

Viel Spa� und meldet Fehler und �hnliches im FlightX Forum oder unter kleineMax@hotmail.com


		---------
		|ENGLISH|
		---------

Changes
----------
With this Patch following things were improved/changed in the Duesseldorf scenery by Thomas Ruth:
- all decorative Vehicle-ways adjusted
- fences moved/corrected
- streets moved/corrected
- landclass moved
- heading of 05L/23R corrected
- taxiways aligned to an aerial image and airport chart
- considered the latest construction at the airport (exp. taxiway M moved and added N,L; and more), according to the GND-chart
- all parking positions added (93 total now), only double occupancy and some GA missing
- align parking-positions to GND-Chart
- mimic apron markings with in the capabilities of ADE
- all airport buildings aligned to aerial images (the light posts, blast fences, western offices and sky train were corrected in GMAX)
- assigned airlines to the parking positions
- added/changed T-offsets
- corrected apron layout


Installation:
-------------
Just deactivate and delete the old EDDL scenery, this counts for every EDDL-Scenery, even non-Thomas Ruth one.
After This copy the "tom_eddl_ME" folder to the "Addon Scenery" folder in your root directory of FSX, then just activate the scenery in FSX.
PS: To prevent errors, add the scenery ad highest priority (1) in the SceneryLib (at the top)

Have fun and be free to contact me at kleinemax@hotmail.de if you have any problems