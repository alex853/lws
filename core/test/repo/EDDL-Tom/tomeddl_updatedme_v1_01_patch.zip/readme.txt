PATCH EDDL v1.01 by Max Epperlein - FIX
---------------------------------------

Dieses kleine Update sollte die Probleme mit der Kollision an den Parkpositionen beheben. Wem es noch nicht aufgefallen ist: Wenn das Flugzeug mit Bugrad die Bodenmarkierung der Fluggastbruecken beruehrte erhielt man eine Absturzmeldung.


Installation
------------
Dieses Update bezieht sich auf den Download: tomeddl_patchME_v1_0.zip
Einfach den enthaltenen Ordner "tom_eddl_ME" in "Addon Scenery" kopieren und das Ueberschreiben jeglicher Datein und/oder Ordner bestaetigen.
Fertig!

Das naechste mal wenn der FSX in Duesseldorf l�dt sollte alles funktioniert.

Viel Spa� und meldet Fehler und �hnliches im FlightX Forum oder unter kleineMax@hotmail.de


		---------
		|ENGLISH|
		---------


This little update fixes the problem with collision at the parking positions. Maybe you noticed that you get a crash detection when the frontwheel of your aircraft hits the ground pattern of the jetway.


Installation
------------
This update refers to the download: tomeddl_patchME_v1_0.zip
Just copie the including folder "tom_eddl_ME" in the folder "Addon Scenery" and confirm any overwriting request of windows.

The next time you start FSX in Duesseldorf everything should be fine.

Have fun and be free to contact me at kleinemax@hotmail.de if you have any problems